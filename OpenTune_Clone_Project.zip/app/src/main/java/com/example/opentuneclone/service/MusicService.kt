package com.example.opentuneclone.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.media.app.NotificationCompat.MediaStyle
import androidx.media.session.MediaButtonReceiver
import android.support.v4.media.session.MediaSessionCompat
import android.support.v4.media.MediaMetadataCompat
import android.support.v4.media.session.PlaybackStateCompat
import com.example.opentuneclone.R
import com.example.opentuneclone.activities.PlayerActivity
import java.io.File

class MusicService : Service() {
    private var mediaPlayer: MediaPlayer? = null
    private lateinit var mediaSession: MediaSessionCompat
    private val handler = Handler()
    private var isPlaying = false

    override fun onCreate() {
        super.onCreate()
        mediaSession = MediaSessionCompat(this, "MusicService")
        mediaSession.isActive = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        MediaButtonReceiver.handleIntent(mediaSession, intent)
        when(intent?.action) {
            "PLAY_LOCAL" -> {
                val path = intent.getStringExtra("song_path") ?: return START_NOT_STICKY
                playLocal(path)
            }
            "PLAY_ONLINE" -> {
                val url = intent.getStringExtra("url") ?: return START_NOT_STICKY
                val title = intent.getStringExtra("title") ?: "Online Song"
                playOnline(url, title)
            }
            "PAUSE" -> { mediaPlayer?.pause(); isPlaying=false; updateNotification("Paused") }
            "RESUME" -> { mediaPlayer?.start(); isPlaying=true; updateNotification("Playing") }
            "STOP" -> stopSelf()
        }
        return START_STICKY
    }

    private fun playLocal(path: String) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(path)
            prepare()
            start()
        }
        isPlaying = true
        val title = File(path).name
        updateNotification(title)
    }

    private fun playOnline(url: String, title: String) {
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setDataSource(url)
            prepareAsync()
            setOnPreparedListener { it.start(); isPlaying=true; updateNotification(title) }
        }
    }

    private fun getAlbumArt(path: String): android.graphics.Bitmap? {
        return try {
            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(path)
            val art = mmr.embeddedPicture
            if (art != null) BitmapFactory.decodeByteArray(art, 0, art.size) else null
        } catch (e: Exception) { null }
    }

    private fun updateMediaSession(title: String) {
        val metadata = MediaMetadataCompat.Builder()
            .putString(MediaMetadataCompat.METADATA_KEY_TITLE, title)
            .build()
        mediaSession.setMetadata(metadata)
        val state = PlaybackStateCompat.Builder()
            .setActions(PlaybackStateCompat.ACTION_PLAY or PlaybackStateCompat.ACTION_PAUSE or PlaybackStateCompat.ACTION_STOP)
            .setState(if (isPlaying) PlaybackStateCompat.STATE_PLAYING else PlaybackStateCompat.STATE_PAUSED, mediaPlayer?.currentPosition?.toLong() ?: 0, 1.0f)
            .build()
        mediaSession.setPlaybackState(state)
    }

    private fun updateNotification(title: String) {
        updateMediaSession(title)
        val channelId = "music_channel"
        val mgr = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            mgr.createNotificationChannel(NotificationChannel(channelId, "Music", NotificationManager.IMPORTANCE_LOW))
        }
        val main = Intent(this, PlayerActivity::class.java).apply { putExtra("title", title) }
        val pending = PendingIntent.getActivity(this, 0, main, PendingIntent.FLAG_IMMUTABLE)

        val playPauseIntent = Intent(this, MusicService::class.java).apply { action = if (isPlaying) "PAUSE" else "RESUME" }
        val playPending = PendingIntent.getService(this, 1, playPauseIntent, PendingIntent.FLAG_IMMUTABLE)

        val stopPending = PendingIntent.getService(this, 2, Intent(this, MusicService::class.java).apply { action = "STOP" }, PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle(title)
            .setContentText(if (isPlaying) "Playing" else "Paused")
            .setSmallIcon(R.drawable.ic_music_note)
            .setContentIntent(pending)
            .addAction(R.drawable.ic_pause, if (isPlaying) "Pause" else "Play", playPending)
            .addAction(R.drawable.ic_stop, "Stop", stopPending)
            .setStyle(MediaStyle().setMediaSession(mediaSession.sessionToken))
            .setOngoing(isPlaying)
            .build()

        startForeground(1, notification)
    }

    override fun onDestroy() {
        mediaPlayer?.release()
        mediaSession.release()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
