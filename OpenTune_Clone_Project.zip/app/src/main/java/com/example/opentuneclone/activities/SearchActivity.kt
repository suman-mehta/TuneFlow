package com.example.opentuneclone.activities

import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.opentuneclone.R
import com.example.opentuneclone.network.InvidiousApi
import kotlin.concurrent.thread

class SearchActivity : AppCompatActivity() {
    private lateinit var searchBox: EditText
    private lateinit var listView: ListView
    private val results = mutableListOf<Map<String,String>>()
    private var downloadId: Long = -1L

    private val onCompleteReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val id = intent?.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L) ?: -1L
            if (id == downloadId) {
                Toast.makeText(this@SearchActivity, "Download complete", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        searchBox = findViewById(R.id.searchBox)
        listView = findViewById(R.id.listView)
        registerReceiver(onCompleteReceiver, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE))

        listView.setOnItemClickListener { _, _, pos, _ ->
            val item = results[pos]
            AlertDialog.Builder(this)
                .setTitle(item["title"])
                .setItems(arrayOf("Play Online","Download")) { _, which ->
                    when(which) {
                        0 -> { // play online
                            thread {
                                val stream = InvidiousApi.getStreamUrl(item["videoId"]!!)
                                if (stream != null) {
                                    val i = Intent(this, MusicService::class.java).apply {
                                        action = "PLAY_ONLINE"
                                        putExtra("url", stream)
                                        putExtra("title", item["title"])
                                    }
                                    startService(i)
                                } else runOnUiThread {
                                    Toast.makeText(this, "Stream not found", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                        1 -> { // download
                            thread {
                                val stream = InvidiousApi.getStreamUrl(item["videoId"]!!)
                                if (stream != null) {
                                    val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                                    val uri = Uri.parse(stream)
                                    val req = DownloadManager.Request(uri)
                                        .setTitle(item["title"])
                                        .setDescription("Downloading")
                                        .setAllowedOverMetered(true)
                                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_MUSIC, "${'$'}{item["title"]}.mp3")
                                    downloadId = dm.enqueue(req)
                                    runOnUiThread { Toast.makeText(this@SearchActivity, "Download started", Toast.LENGTH_SHORT).show() }
                                } else runOnUiThread {
                                    Toast.makeText(this, "Download url not found", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }.show()
        }

        val searchBtn = findViewById<Button>(R.id.searchBtn)
        searchBtn.setOnClickListener {
            val q = searchBox.text.toString().trim()
            if (q.isNotEmpty()) {
                thread {
                    val data = InvidiousApi.search(q)
                    results.clear()
                    results.addAll(data)
                    val titles = data.map { it["title"] ?: "" }
                    runOnUiThread {
                        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, titles)
                        listView.adapter = adapter
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(onCompleteReceiver)
    }
}
