package com.example.opentuneclone.adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.opentuneclone.R
import java.io.File

class SongAdapter(private val songs: List<File>, private val onClick: (Int)->Unit) : RecyclerView.Adapter<SongAdapter.VH>() {
    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val title: TextView = view.findViewById(R.id.songTitle)
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_song, parent, false)
        return VH(v)
    }
    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.title.text = songs[position].name
        holder.itemView.setOnClickListener { onClick(position) }
    }
    override fun getItemCount(): Int = songs.size
}
