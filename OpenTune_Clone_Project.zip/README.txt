OpenTuneClone - Minimal Android Studio project
---------------------------------------------
Contents:
 - app module with Kotlin sources (MainActivity, SearchActivity, PlayerActivity, MusicService)
 - Invidious API helper for search/stream (uses an instance which may change)
 - Basic layouts and placeholder drawables

How to open:
 1) Copy this folder into your machine.
 2) Open Android Studio -> Open an existing project -> select this folder.
 3) Let Android Studio sync Gradle (it will download required dependencies).

Notes:
 - Invidious public instances change frequently. If search/stream fails, change BASE in InvidiousApi.kt to a working instance (e.g., https://yewtu.cafe/api/v1 or another public instance).
 - This is a minimal demo. For production you should handle network errors, runtime permissions, and update UI/UX.
