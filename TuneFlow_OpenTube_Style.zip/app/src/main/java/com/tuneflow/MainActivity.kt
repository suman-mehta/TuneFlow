package com.tuneflow

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import android.widget.EditText
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val searchBox = findViewById<EditText>(R.id.searchBox)
        val searchButton = findViewById<Button>(R.id.searchButton)
        val songList = findViewById<RecyclerView>(R.id.songList)

        searchButton.setOnClickListener {
            val query = searchBox.text.toString()
            // TODO: call Piped API for search and update RecyclerView with results
        }
    }
}