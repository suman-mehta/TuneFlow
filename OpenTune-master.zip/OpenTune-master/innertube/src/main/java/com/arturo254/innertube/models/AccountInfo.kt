package com.arturo254.innertube.models

data class AccountInfo(
    val name: String,
    val email: String?,
    val channelHandle: String?,
)
