package com.arturo254.opentune.constants

enum class HistorySource {
    LOCAL, REMOTE
}
