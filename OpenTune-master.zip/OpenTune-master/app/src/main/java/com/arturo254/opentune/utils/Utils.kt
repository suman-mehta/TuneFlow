package com.arturo254.opentune.utils

fun reportException(throwable: Throwable) {
    throwable.printStackTrace()
}
