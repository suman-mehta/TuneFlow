package com.example.opentuneclone.activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.opentuneclone.R

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // host a PreferenceFragment
        supportFragmentManager
            .beginTransaction()
            .replace(android.R.id.content, SettingsFragment())
            .commit()
    }
}
