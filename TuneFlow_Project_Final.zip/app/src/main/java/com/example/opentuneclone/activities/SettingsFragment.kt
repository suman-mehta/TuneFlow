package com.example.opentuneclone.activities

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.preference.Preference
import androidx.preference.PreferenceFragmentCompat
import com.example.opentuneclone.R

class SettingsFragment : PreferenceFragmentCompat() {
    override fun onCreatePreferences(savedInstanceState: Bundle?, rootKey: String?) {
        setPreferencesFromResource(R.xml.root_preferences, rootKey)

        findPreference<Preference>("contact_support")?.setOnPreferenceClickListener {
            val email = "sumankumardphs438@gmail.com"
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
                putExtra(Intent.EXTRA_SUBJECT, "TuneFlow Support")
            }
            context?.let {
                if (intent.resolveActivity(it.packageManager) != null) startActivity(intent)
            }
            true
        }
    }
}
