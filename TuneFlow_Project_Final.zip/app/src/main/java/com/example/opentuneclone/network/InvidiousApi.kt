package com.example.opentuneclone.network

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject

object InvidiousApi {
    private const val BASE = "https://yewtu.cafe/api/v1" // public instance (may change)
    private val client = OkHttpClient()

    fun search(query: String): List<Map<String,String>> {
        val url = "$BASE/search?q=${'$'}{query.replace(" ", "+")}"
        val req = Request.Builder().url(url).build()
        client.newCall(req).execute().use { res ->
            val body = res.body?.string() ?: return emptyList()
            val arr = JSONArray(body)
            val list = mutableListOf<Map<String,String>>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val thumb = if (o.has("videoThumbnails")) o.getJSONArray("videoThumbnails").getJSONObject(0).optString("url") else ""
                list.add(mapOf("title" to o.optString("title"), "videoId" to o.optString("videoId"), "author" to o.optString("author"), "thumbnail" to thumb))
            }
            return list
        }
    }

    fun getStreamUrl(videoId: String): String? {
        val url = "$BASE/videos/${'$'}videoId"
        val req = Request.Builder().url(url).build()
        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) return null
            val body = res.body?.string() ?: return null
            val obj = JSONObject(body)
            val arr = when {
                obj.has("adaptiveFormats") -> obj.getJSONArray("adaptiveFormats")
                obj.has("formats") -> obj.getJSONArray("formats")
                else -> null
            } ?: return null
            var best: String? = null
            var bestBr = 0
            for (i in 0 until arr.length()) {
                val f = arr.getJSONObject(i)
                val mime = f.optString("type")
                val urlStr = f.optString("url")
                val br = f.optInt("bitrate", 0)
                if (mime.contains("audio")) {
                    if (br > bestBr) { bestBr = br; best = urlStr }
                }
            }
            return best
        }
    }
}
