package com.example.opentuneclone.utils

import android.content.Context
import android.content.Intent
import android.widget.ImageButton
import android.widget.TextView
import com.example.opentuneclone.service.MusicService

/**
 * Simple helper to hook mini-player UI to MusicService actions.
 * This is a lightweight controller that sends Intents to the service.
 */
class PlayerController(private val ctx: Context, private val titleView: TextView,
                       private val playBtn: ImageButton, private val prevBtn: ImageButton, private val nextBtn: ImageButton) {

    fun bind(title: String) {
        titleView.text = title
    }

    fun setListeners() {
        playBtn.setOnClickListener {
            val intent = Intent(ctx, MusicService::class.java)
            intent.action = "TOGGLE"
            ctx.startService(intent)
        }
        prevBtn.setOnClickListener {
            val intent = Intent(ctx, MusicService::class.java)
            intent.action = "PREV"
            ctx.startService(intent)
        }
        nextBtn.setOnClickListener {
            val intent = Intent(ctx, MusicService::class.java)
            intent.action = "NEXT"
            ctx.startService(intent)
        }
    }
}
