package com.example.opentuneclone.activities

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.opentuneclone.R
import com.example.opentuneclone.adapters.SongAdapter
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: SongAdapter
    private var songs: ArrayList<File> = arrayListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        val btnSearch = findViewById<Button>(R.id.btn_search)
        btnSearch.setOnClickListener {
            startActivity(Intent(this, SearchActivity::class.java))
        }
        // Long-press opens Settings
        btnSearch.setOnLongClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
            true
        }


        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 101)
            } else loadSongs()
        } else loadSongs()
    }

    private fun loadSongs() {
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
        songs = findSongs(dir)
        if (songs.isEmpty()) {
            Toast.makeText(this, "No local songs found in Music folder", Toast.LENGTH_SHORT).show()
        }
        adapter = SongAdapter(songs) { pos -> playSong(pos) }
        recyclerView.adapter = adapter
    }

    private fun findSongs(dir: File?): ArrayList<File> {
        val list = arrayListOf<File>()
        val files = dir?.listFiles()
        files?.forEach { f ->
            if (f.isDirectory) list.addAll(findSongs(f))
            else if (f.name.endsWith(".mp3") || f.name.endsWith(".wav")) list.add(f)
        }
        return list
    }

    private fun playSong(position: Int) {
        val intent = Intent(this, MusicService::class.java).apply {
            action = "PLAY_LOCAL"
            putExtra("song_path", songs[position].absolutePath)
        }
        ContextCompat.startForegroundService(this, intent)
    }
}
