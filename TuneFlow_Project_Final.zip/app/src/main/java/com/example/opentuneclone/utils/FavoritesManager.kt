package com.example.opentuneclone.utils

import android.content.Context
import android.content.SharedPreferences

class FavoritesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("tuneflow_prefs", Context.MODE_PRIVATE)

    fun isFavorite(path: String): Boolean {
        return prefs.getBoolean(path, false)
    }

    fun toggleFavorite(path: String) {
        val current = isFavorite(path)
        prefs.edit().putBoolean(path, !current).apply()
    }
}
