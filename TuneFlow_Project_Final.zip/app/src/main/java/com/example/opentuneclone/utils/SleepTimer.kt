package com.example.opentuneclone.utils

import android.content.Context
import android.content.Intent
import android.os.CountDownTimer
import com.example.opentuneclone.service.MusicService

class SleepTimer(private val ctx: Context) {
    private var timer: CountDownTimer? = null

    fun start(minutes: Int) {
        stop()
        timer = object : CountDownTimer(minutes * 60_000L, 1000L) {
            override fun onTick(millisUntilFinished: Long) {}
            override fun onFinish() {
                // stop playback
                val intent = Intent(ctx, MusicService::class.java).apply { action = "STOP" }
                ctx.startService(intent)
            }
        }.start()
    }

    fun stop() {
        timer?.cancel()
        timer = null
    }
}
